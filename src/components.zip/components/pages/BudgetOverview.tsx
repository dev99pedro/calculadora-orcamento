import BudgetSummary from '../organisms/BudgetSummary';

function BudgetOverview(): JSX.Element {
  return (
    <BudgetSummary />
  );
}

export default BudgetOverview;

// BudgetOverview
