import { ReactComponent as SelectedIcon } from '../../assets/svgs/selected.svg';

function Selected(): JSX.Element {
  return (
    <SelectedIcon />
  );
}

export default Selected;
